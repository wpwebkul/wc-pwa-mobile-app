<?php
/**
 * Register Api.
 *
 * @package PWA stripe payment gateway.
 * @version 1.0.0
 */

namespace PWASTRIPE\Api;

use PWASTRIPE\Helper;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Pwastripe_Register_Api' ) ) {
	/**
	 * Register api class.
	 */
	class Pwastripe_Register_Api {

		/**
		 * Stripe helper.
		 *
		 * @var object Stripe helper object.
		 */
		protected $helper;


		/**
		 * Register api constructor.
		 */
		public function __construct() {

			$this->helper = new Helper\Pwastripe_Helper();

			add_action( 'rest_api_init', array( $this, 'register_rest_api_schema' ) );

		}

		/**
		 * Register rest apis schema.
		 */
		public function register_rest_api_schema() {

			register_rest_route(
				'pwa/v1',
				'generateStripeIntent',
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'pwastripe_create_payment_intent' ),
					'permission_callback' => '__return_true',
				)
			);
		}

		/**
		 * Create stripe payment Intent.
		 *
		 * @param object $request Request object.
		 * @throws mixed $payment_intent Intent or error string.
		 */
		public function pwastripe_create_payment_intent( $request ) {
			try {
				$params = $request->get_params();
				if ( ! empty( $params['orderkey'] ) ) {
					$order_key = sanitize_text_field( $params['orderkey'] );
				} else {
					throw new \Exception( esc_html__( 'Invalid order key!', 'pwastripe' ) );
				}

				$data_store     = new \WC_Order_Data_Store_CPT();
				$order_id       = $data_store->get_order_id_by_order_key( $order_key );
				$payment_intent = $this->helper->get_payment_intent( $order_id );

				if ( ! empty( $payment_intent ) && is_object( $payment_intent ) ) {

					wp_send_json_success( $payment_intent );

				} else {
					throw new \Exception( $payment_intent );
				}
			} catch ( \Exception $e ) {
				wp_send_json_error( $e->getMessage() );
			}
		}



	}
}
