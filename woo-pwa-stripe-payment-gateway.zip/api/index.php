<?php 
/**
 * Silence is golden.
 *
 * @package WooCommerce PWA app Stripe payment gateway
 * @version 1.0.0
 */
