<?php
/**
 * Stripe helper functions.
 *
 * @package PWA stripe payment gateway.
 * @version 1.0.0
 */

namespace PWASTRIPE\Helper;

use \Stripe as Stripe;


defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Pwastripe_Helper' ) ) {
	/**
	 * Stripe helper class.
	 */
	class Pwastripe_Helper {

		/**
		 * Secret key property.
		 *
		 * @var string Stripe secret key.
		 */
		protected $secret_key;

		/**
		 * Constructor.
		 */
		public function __construct() {

			$stripe_config = get_option( 'woocommerce_stripe_settings' );

			if ( ! empty( $stripe_config ) ) {
				$test_mode        = 'yes' === $stripe_config['testmode'];
				$this->secret_key = $test_mode ? $stripe_config['test_secret_key'] : $stripe_config['secret_key'];
			}

		}

		/**
		 * Generate stripe payment intent.
		 *
		 * @param int $order_id Order id.
		 * @throws string Exeception error string.
		 *
		 * @return mixed $payment_intent Payment intent | error.
		 */
		public function get_payment_intent( $order_id = 0 ) {
			try {

				$order = new \WC_Order( $order_id );
				if ( empty( $order ) ) {
					throw new \Exception( esc_html__( 'Invalid order id!', 'pwastripe' ), 1 );
				}

				$customer          = $order->get_user();
				$address           = $order->get_address( 'shipping' );
				$first_name        = $address['first_name'];
				$last_name         = $address['last_name'];
				$order_intent_data = array(
					'amount'        => absint( wc_format_decimal( ( (float) $order->get_total() * 100 ), wc_get_price_decimals() ) ),
					'currency'      => strtolower( get_woocommerce_currency() ),
					'description'   => get_bloginfo() . ' - Order ' . $order_id,
					'receipt_email' => $customer->data->user_email,
					'metadata'      => array(
						'order_id'       => $order_id,
						'site_url'       => site_url(),
						'customer_email' => $customer->data->user_email,
						'customer_name'  => $customer->data->display_name,
						'mode'           => 'PWA App',
					),
					'shipping'      => array(
						'address' => array(
							'line2'       => $address['address_2'],
							'line1'       => $address['address_1'],
							'state'       => $address['state'],
							'postal_code' => $address['postcode'],
							'city'        => $address['city'],
							'country'     => $address['country'],
						),
						'name'    => "{$first_name} {$last_name}",
					),
				);

				if ( ! empty( $this->secret_key ) ) {
					$stripe             = new Stripe\StripeClient( $this->secret_key );
					$stripe_customer_id = $this->create_stripe_customer( $customer, $stripe );
					if ( ! empty( $stripe_customer_id ) ) {
						$order_intent_data['customer'] = $stripe_customer_id;
						update_post_meta( $order_id, '_stripe_customer_id', $stripe_customer_id );
					}
					$payment_intent = $stripe->paymentIntents->create( $order_intent_data ); //phpcs:ignore
					return  $payment_intent;
				} else {
					throw new \Exception( esc_html__( 'Please configure stripe payment configurations!', 'pwastripe' ), 1 );
				}
			} catch ( \Exception $e ) {
				return $e->getMessage();
			}
		}

		/**
		 * Create stripe customer.
		 *
		 * @param object $customer Customer object.
		 * @param object $stripe Stripe class object.
		 *
		 * @return mixed $stripe_customer_id Stripe customer id or error.
		 */
		public function create_stripe_customer( $customer, $stripe ) {
			try {
				$customer_id        = $customer->ID;
				$stripe_customer_id = get_user_meta( $customer_id, '_wkwcpwa_stripe_customer_id', true );
				if ( empty( $stripe_customer_id ) ) {
					$customer_info      = array(
						'name'  => $customer->data->display_name,
						'email' => $customer->data->user_email,
					);
					$response           = $stripe->customers->create( $customer_info );
					$stripe_customer_id = $response->id;
					update_user_meta( $customer_id, '_wkwcpwa_stripe_customer_id', $stripe_customer_id );
				}
				return $stripe_customer_id;
			} catch ( \Exception $e ) {
				return $e->getMessage();
			}
		}

		public function create_stripe_refund( $order_id, $amount = 0 ) {
			try {
				$args      = array();
				$intent_id = get_post_meta( $order_id, '_stripe_intent_id', true );
				if ( ! empty( $intent_id ) ) {
					$args['payment_intent'] = $intent_id;
					if ( ! empty( $amount ) ) {
						$args['amount'] = $amount;
					}

					$stripe = new Stripe\StripeClient( $this->secret_key );

					$stripe_refund = $stripe->refunds->create( $args );
					update_post_meta( $order_id, '_stripe_refund_id', $stripe_refund->id );
					return $stripe_refund;
				}
			} catch ( \Exception $e ) {
				return $e->getMessage();
			}
		}


	}
}
