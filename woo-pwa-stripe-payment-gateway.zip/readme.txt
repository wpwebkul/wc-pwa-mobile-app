=== PWA stripe payment gateway ===

Contributors: Webkul
Requires at least: 5.0
Tested up to: 6.2
Stable tag: 1.0.0
Requires PHP: 7.4
Tested up to PHP: 8.1
WC requires at least: 5.0
WC tested up to: 7.6

Tags: pwa, progressive web app stripe payment gateway, woo pwa stripe payment gateway

License: license.txt file included with plugin
License URI: https://store.webkul.com/license.html

This plugin added the stripe payment gateway credit card payment feature in pwa application.

== Installation ==

1. Upload the `pwa-stripe-payment-gateway-addon` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

No questions asked yet

For any Query please generate a ticket at https://webkul.com/ticket/

== 1.0.0 ==
Initial release
