<?php
/**
 * Admin functions
 *
 * @package PWA stripe payment gateway
 * @version 1.0.0
 */

namespace PWASTRIPE\Includes\Admin;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Pwastripe_Front_Functions' ) ) {
	/**
	 * Admin functions class
	 */
	class Pwastripe_Admin_Functions {

		/**
		 * Constructor.
		 */
		public function __construct() {

		}

		public function pwastripe_payment_gateways( $gateways ) {
			global $pagenow;
			if ( 'post.php' === $pagenow ) {
				$post_id   = ! empty( $_GET['post'] ) ? sanitize_text_field( $_GET['post'] ) : 0;
				$post_type = get_post_type( $post_id );
				if ( 'shop_order' === $post_type ) {
					$created_by = get_post_meta( $post_id, '_created_via', true );
					if ( 'graphql-api' === $created_by && ! empty( $gateways ) ) {
						foreach ( $gateways as $gateway ) {
							if ( is_object( $gateway ) ) {
								if ( ! empty( $gateway->supports ) ) {
									foreach ( $gateway->supports as $key => $supports ) {
										if ( 'refunds' === $supports ) {
											unset( $gateway->supports[ $key ] );
										}
									}
								}
							}
						}
					}
				}
			}
			return $gateways;

		}

	}

}
