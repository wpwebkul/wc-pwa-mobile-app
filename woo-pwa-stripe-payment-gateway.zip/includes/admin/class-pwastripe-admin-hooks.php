<?php
/**
 * Admin hooks
 *
 * @package PWA stripe payment gateway
 * @version 1.0.0
 */

namespace PWASTRIPE\Includes\Admin;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Pwastripe_Admin_Hooks' ) ) {
	/**
	 * Admin hooks class
	 */
	class Pwastripe_Admin_Hooks {

		/**
		 * Construct
		 */
		public function __construct() {

			$function_handler = new Pwastripe_Admin_Functions();

			add_filter( 'woocommerce_payment_gateways', array( $function_handler, 'pwastripe_payment_gateways' ), 99 );

		}

	}

}
