<?php
/**
 * File handler.
 *
 * @package PWA stripe payment gateway.
 * @version 1.0.0
 */

namespace PWASTRIPE\Includes;

use PWASTRIPE\Includes\Admin;
use PWASTRIPE\Includes\Front;
use PWASTRIPE\Api;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Pwastripe_File_Handler' ) ) {

	/**
	 * File handler class.
	 */
	class Pwastripe_File_Handler {

		/**
		 * Construct.
		 */
		public function __construct() {
			if ( is_admin() ) {
				new Admin\Pwastripe_Admin_Hooks();
			}
			new Front\Pwastripe_Front_Hooks();
			new Api\Pwastripe_Register_Api();

		}

	}

}
