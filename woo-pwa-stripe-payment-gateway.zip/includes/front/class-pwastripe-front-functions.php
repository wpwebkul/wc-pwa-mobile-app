<?php
/**
 * Front functions.
 *
 * @package PWA stripe payment gateway.
 * @version 1.0.0
 */

namespace PWASTRIPE\Includes\Front;

use WKWCPWA\Helper\Header;


defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Pwastripe_Front_Functions' ) ) {
	/**
	 * Front functions class.
	 */
	class Pwastripe_Front_Functions {



		/**
		 * PWA scripts enqueue function.
		 *
		 * @return void
		 */
		public function pwastripe_enqueue_scripts() {

			$header_helper = new Header\Wkwcpwa_Pwa_Header();
			$header_helper->wkwcpwa_enqueue_style( 'pwastripe-style', PWASTRIPE_PLUGIN_URL . 'assets/css/app.css', PWASTRIPE_SCRIPT_VERSION, array() );

			$header_helper->wkwcpwa_enqueue_script( 'pwastripe-script', PWASTRIPE_PLUGIN_URL . 'assets/js/app.js', PWASTRIPE_SCRIPT_VERSION );
		}

		/**
		 * Localize stripe data.
		 *
		 * @param array $data Localize data.
		 *
		 * @return array $data localized data.
		 */
		public function pwastripe_localize_data( $data ) {
			$data['translations'] = $data['translations'] + array(
				'transaction_id'       => esc_html__( 'Transaction id', 'pwastripe' ),
				'pay_now'              => esc_html__( 'Pay Now', 'pwastripe' ),
				'try_again_note'       => esc_html__( 'Please try again!', 'pwastripe' ),
				'try_again'            => esc_html__( 'Try again', 'pwastripe' ),
				'continue'             => esc_html__( 'Continue', 'pwastripe' ),
				'payment_success_note' => esc_html__( 'Payment received, thank you for your purchase!', 'pwastripe' ),
				'payment_failed'       => esc_html__( 'Payment Failed!', 'pwastripe' ),
				'payment_success'      => esc_html__( 'Payment Successfull!', 'pwastripe' ),
				'requesting'           => esc_html__( 'Requesting', 'pwastripe' ),
				'complete_payment'     => esc_html__( 'Complete payment', 'pwastripe' ),
			);
			$data['stripeData']   = array(
				'stripe_config' => get_option( 'woocommerce_stripe_settings' ),
				'admin_ajax'    => admin_url( 'admin-ajax.php' ),
				'stripe_nonce'  => wp_create_nonce( 'wkwcpwa_stripe_nonce' ),
			);

			return $data;
		}
		/**
		 * Add stripe payment gateway in payment gateway request.
		 *
		 * @param array $gateways Payment gateways list.
		 * @param array $args Request args.
		 *
		 * @return array $gateways Payment gateways list.
		 */
		public function pwastripe_modify_payment_gateways_response( $gateways, $args ) {
			$all_gateways = \WC()->payment_gateways()->get_available_payment_gateways();
			if ( ! empty( $all_gateways['stripe'] ) && ! empty( $args['where']['addons'] ) && true === $args['where']['addons'] ) {
				$gateways['stripe'] = $all_gateways['stripe'];
			}
			return $gateways;
		}


	}

}
