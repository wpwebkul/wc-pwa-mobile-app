<?php
/**
 * Front hooks.
 *
 * @package PWA stripe payment gateway.
 * @version 1.0.0
 */

namespace PWASTRIPE\Includes\Front;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Pwastripe_Front_Hooks' ) ) {
	/**
	 * Front hooks class.
	 */
	class Pwastripe_Front_Hooks {

		/**
		 * Construct.
		 */
		public function __construct() {

			$function_handler = new Pwastripe_Front_Functions();
			add_action( 'wkwcpwa_pwa_header', array( $function_handler, 'pwastripe_enqueue_scripts' ), 99 );

			add_filter( 'graphql_woocommerce_authorized_to_update_orders', '__return_true', 10 );

			add_filter( 'wkwcpwa_app_localized_data', array( $function_handler, 'pwastripe_localize_data' ), 20 );
		}

	}

}
