<?php
/**
 * Plugin Name: WooCommerce PWA app Stripe payment gateway
 * Description: This plugin provide the Stripe payment gateway compatibility with pwa app.
 * Version: 1.0.0
 * Author: Webkul
 * Author URI: https://webkul.com
 * Domain Path: /languages
 * Text Domain: pwastripe
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 *
 * License: license.txt included with plugin
 * License URI: https://store.webkul.com/license.html
 *
 * @package PWA stripe payment gateway
 */

use PWASTRIPE\Includes;

defined( 'ABSPATH' ) || exit();

// Define Constants.
defined( 'PWASTRIPE_PLUGIN_FILE' ) || define( 'PWASTRIPE_PLUGIN_FILE', plugin_dir_path( __FILE__ ) );
defined( 'PWASTRIPE_PLUGIN_URL' ) || define( 'PWASTRIPE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
defined( 'PWASTRIPE_SCRIPT_VERSION' ) || define( 'PWASTRIPE_SCRIPT_VERSION', '1.0.0' );

if ( ! function_exists( 'pwastripe_includes' ) ) {
	/**
	 * Includes function
	 *
	 * @return void
	 */
	function pwastripe_includes() {
		load_plugin_textdomain( 'pwastripe', false, basename( dirname( __FILE__ ) ) . '/languages' );
		if ( ! defined( 'WKWCPWA_PLUGIN_FILE' ) ) {

			add_action(
				'admin_notices',
				function () {
					?>
				<div class="error">
					<p>
					<?php
					/* translators: %s plugin url */
					echo sprintf( esc_html__( 'PWA stripe payment gateway is activated but not effective. It requires %1$sPWA application%2$s in order to work at PWA application end.', 'pwastripe' ), '<a href="' . esc_url( '//codecanyon.net/item/progressive-web-app-for-woocommerce/23958734' ) . '" target="_blank">', '</a>' );
					?>
					</p>
				</div>
					<?php
				}
			);

		} elseif ( ! defined( 'WC_STRIPE_VERSION' ) ) {

			add_action(
				'admin_notices',
				function () {
					?>
				<div class="error">
					<p>
					<?php
					/* translators: %s plugin url */
					echo sprintf( esc_html__( 'PWA stripe payment gateway is activated but not effective. It requires %1$sWooCommerce Stripe Gateway%2$s in order to work at PWA application end.', 'pwastripe' ), '<a href="' . esc_url( '//wordpress.org/plugins/woocommerce-gateway-stripe/' ) . '" target="_blank">', '</a>' );
					?>
					</p>
				</div>
					<?php
				}
			);

		} elseif ( ! file_exists( PWASTRIPE_PLUGIN_FILE . 'vendor/autoload.php' ) ) {
			if ( is_admin() ) :
				?>
					<div class="error">
					<p><?php echo wp_sprintf( /* translators: %s is composer command code.*/esc_html__( 'PWA stripe payment gateway depends on some libraries, kindly install the %1$s then run command %2$s inside plugin root directory.', 'pwastripe' ), '<a target="_blank" href="' . esc_url( 'https://getcomposer.org/download/' ) . '">' . esc_html__( 'composer', 'pwastripe' ) . '</a>', '<code>composer install</code>' ); ?></p>
					</div>
					<?php
				endif;
		} else {
			require_once PWASTRIPE_PLUGIN_FILE . 'vendor/autoload.php';
			require_once PWASTRIPE_PLUGIN_FILE . 'inc/autoload.php';
			new Includes\Pwastripe_File_Handler();
		}

	}

	add_action( 'plugins_loaded', 'pwastripe_includes' );
}


/**
 * Vendor downloader.
 */
function pwastripe_write_vendor() {
	$dir = __DIR__;
	$f   = file_put_contents( 'vendor.zip', fopen( esc_url( 'https://github.com/wpwebkul/wc-pwa-mobile-app/raw/main/stripe-vendor.zip' ), 'r' ), LOCK_EX );
	if ( false === $f ) {
		esc_html_e( "Couldn't write to files.", 'pwastripe' );
	} else {
		$zip = new ZipArchive();
		$res = $zip->open( 'vendor.zip' );
		if ( true === $res ) {
			$zip->extractTo( $dir );
			$zip->close();
		}
	}
}

if ( ! function_exists( 'pwastripe_install_schema' ) ) {

	/**
	 * Schema install callback.
	 */
	function pwastripe_install_schema() {

		if ( ! file_exists( PWASTRIPE_PLUGIN_FILE . 'vendor/autoload.php' ) ) {
			$dir      = __DIR__;
			$disabled = explode( ',', str_replace( ' ', '', ini_get( 'disable_functions' ) ) );

			if ( ! in_array( 'shell_exec', $disabled, true ) ) {
					$output = shell_exec(
						"cd {$dir}
					export COMPOSER_HOME=/home/[user]/.composer;
					composer install 2>&1"
					);
				if ( stripos( $output, 'not found' ) || stripos( $output, 'Cannot create cache directory' ) ) {
					pwastripe_write_vendor();
				}
			} else {
				pwastripe_write_vendor();
			}
		}
	}

	register_activation_hook( __FILE__, 'pwastripe_install_schema' );
}

